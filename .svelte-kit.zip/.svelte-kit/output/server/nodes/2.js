import * as universal from '../entries/pages/_page.ts.js';

export const index = 2;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/_page.svelte.js')).default;
export { universal };
export const universal_id = "src/routes/+page.ts";
export const imports = ["_app/immutable/nodes/2.34aface8.js","_app/immutable/chunks/scheduler.e1743921.js","_app/immutable/chunks/index.0f4af11a.js","_app/immutable/chunks/each.e59479a4.js","_app/immutable/chunks/runtime.esm.675b5ffb.js","_app/immutable/chunks/index.805014c1.js","_app/immutable/chunks/SplideSlide.fad18a94.js","_app/immutable/chunks/index.cc1b4819.js","_app/immutable/chunks/fa.cc88b9bd.js"];
export const stylesheets = ["_app/immutable/assets/2.a907a465.css","_app/immutable/assets/fa.95b16411.css"];
export const fonts = [];
