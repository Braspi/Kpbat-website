import * as universal from '../entries/pages/_layout.ts.js';

export const index = 0;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/_layout.svelte.js')).default;
export { universal };
export const universal_id = "src/routes/+layout.ts";
export const imports = ["_app/immutable/nodes/0.15dd31ff.js","_app/immutable/chunks/scheduler.e1743921.js","_app/immutable/chunks/index.0f4af11a.js","_app/immutable/chunks/runtime.esm.675b5ffb.js","_app/immutable/chunks/index.805014c1.js","_app/immutable/chunks/fa.cc88b9bd.js","_app/immutable/chunks/index.cc1b4819.js","_app/immutable/chunks/stores.f470a86d.js","_app/immutable/chunks/singletons.0caa2a30.js","_app/immutable/chunks/each.e59479a4.js"];
export const stylesheets = ["_app/immutable/assets/0.fc013bff.css","_app/immutable/assets/fa.95b16411.css"];
export const fonts = [];
