

export const index = 4;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/gallery/images/_page.svelte.js')).default;
export const imports = ["_app/immutable/nodes/4.80bce1af.js","_app/immutable/chunks/scheduler.e1743921.js","_app/immutable/chunks/index.0f4af11a.js","_app/immutable/chunks/each.e59479a4.js","_app/immutable/chunks/SplideSlide.fad18a94.js","_app/immutable/chunks/stores.f470a86d.js","_app/immutable/chunks/singletons.0caa2a30.js","_app/immutable/chunks/index.805014c1.js","_app/immutable/chunks/store.4e1d6ce8.js"];
export const stylesheets = [];
export const fonts = [];
