

export const index = 1;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/fallbacks/error.svelte.js')).default;
export const imports = ["_app/immutable/nodes/1.73b6de5c.js","_app/immutable/chunks/scheduler.e1743921.js","_app/immutable/chunks/index.0f4af11a.js","_app/immutable/chunks/stores.f470a86d.js","_app/immutable/chunks/singletons.0caa2a30.js","_app/immutable/chunks/index.805014c1.js"];
export const stylesheets = [];
export const fonts = [];
