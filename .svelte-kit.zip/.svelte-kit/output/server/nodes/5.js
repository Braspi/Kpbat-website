

export const index = 5;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/services/_page.svelte.js')).default;
export const imports = ["_app/immutable/nodes/5.1d1c9291.js","_app/immutable/chunks/scheduler.e1743921.js","_app/immutable/chunks/index.0f4af11a.js","_app/immutable/chunks/stores.f470a86d.js","_app/immutable/chunks/singletons.0caa2a30.js","_app/immutable/chunks/index.805014c1.js","_app/immutable/chunks/index.cc1b4819.js","_app/immutable/chunks/runtime.esm.675b5ffb.js"];
export const stylesheets = [];
export const fonts = [];
