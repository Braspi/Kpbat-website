

export const index = 3;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/gallery/_page.svelte.js')).default;
export const imports = ["_app/immutable/nodes/3.2b7ff666.js","_app/immutable/chunks/scheduler.e1743921.js","_app/immutable/chunks/each.e59479a4.js","_app/immutable/chunks/index.0f4af11a.js","_app/immutable/chunks/runtime.esm.675b5ffb.js","_app/immutable/chunks/index.805014c1.js","_app/immutable/chunks/store.4e1d6ce8.js"];
export const stylesheets = [];
export const fonts = [];
