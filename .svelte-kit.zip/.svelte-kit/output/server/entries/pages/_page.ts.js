function generateSlides(length = 7, sig = 0) {
  return Array.from({ length }).map((_, index) => {
    index = sig || index;
    return {
      src: `/img/carousel/${index + 1}.jpg`,
      alt: ``
    };
  });
}
async function load() {
  return {
    slides: generateSlides()
  };
}
export {
  load
};
