import { c as create_ssr_component, a as subscribe } from "../../../chunks/ssr.js";
import { p as page } from "../../../chunks/stores.js";
import { $ as $format } from "../../../chunks/runtime.esm.js";
const Page = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let $$unsubscribe_page;
  let $$unsubscribe__;
  $$unsubscribe_page = subscribe(page, (value) => value);
  $$unsubscribe__ = subscribe($format, (value) => value);
  $$unsubscribe_page();
  $$unsubscribe__();
  return `<section class="min-h-screen bg-light"><div class="flex flex-wrap justify-center items-center h-screen"><div class="grid grid-cols-1 w-[90%] md:grid-cols-3 grid-rows-1 gap-0 md:w-3/4">${``}</div></div></section>`;
});
export {
  Page as default
};
