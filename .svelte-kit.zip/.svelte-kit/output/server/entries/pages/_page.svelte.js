import { n as noop, c as create_ssr_component, a as subscribe, e as escape, v as validate_component, f as assign, i as identity, d as add_attribute, b as each, o as onDestroy } from "../../chunks/ssr.js";
import { $ as $format } from "../../chunks/runtime.esm.js";
import { S as Splide_1, a as SplideSlide } from "../../chunks/SplideSlide.js";
import { faArrowRight } from "@fortawesome/free-solid-svg-icons";
import { F as Fa } from "../../chunks/fa.js";
import { w as writable } from "../../chunks/index.js";
const is_client = typeof window !== "undefined";
let now = is_client ? () => window.performance.now() : () => Date.now();
let raf = is_client ? (cb) => requestAnimationFrame(cb) : noop;
const tasks = /* @__PURE__ */ new Set();
function run_tasks(now2) {
  tasks.forEach((task) => {
    if (!task.c(now2)) {
      tasks.delete(task);
      task.f();
    }
  });
  if (tasks.size !== 0)
    raf(run_tasks);
}
function loop(callback) {
  let task;
  if (tasks.size === 0)
    raf(run_tasks);
  return {
    promise: new Promise((fulfill) => {
      tasks.add(task = { c: callback, f: fulfill });
    }),
    abort() {
      tasks.delete(task);
    }
  };
}
const AboutSection = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let $_, $$unsubscribe__;
  $$unsubscribe__ = subscribe($format, (value) => $_ = value);
  $$unsubscribe__();
  return `<section id="about" class="flex flex-col lg:flex-row gap-5 lg:gap-10 px-4 sm:px-6 lg:px-14 pb-5 lg:pb-10 max-h-[1800px]"><div class="lg:flex-2 relative w-full"><div class="absolute z-10 bottom-16 lg:bottom-24 left-0 bg-white h-[70px] lg:h-[100px] w-[220px] sm:w-[280px] lg:w-[320px] rounded-tr-[30px] lg:rounded-tr-[45px] flex justify-start items-center"><p class="font-semibold text-4xl sm:text-5xl lg:text-6xl translate-y-1 lg:translate-y-2">${escape($_("about.left.first"))}</p></div> <div class="absolute z-10 bottom-0 left-0 bg-white h-[70px] lg:h-[100px] w-[280px] sm:w-[350px] lg:w-[400px] rounded-tr-[30px] lg:rounded-tr-[40px] flex justify-start items-center"><p class="font-semibold text-4xl sm:text-5xl lg:text-6xl">${escape($_("about.left.last"))}</p></div> <img src="img/carousel/4.jpg" alt="hi-png" class="rounded-[30px] lg:rounded-[40px] w-full h-[400px] sm:h-[500px] lg:h-[60vh] object-cover"></div> <div class="flex-1 flex flex-col gap-5 lg:gap-0 lg:justify-between w-full"><div class="bg-[#F1EAE2] rounded-[30px] lg:rounded-[40px] p-6 lg:p-8 h-[250px] sm:h-[280px] xl:h-[40vh]"><div class="flex items-center justify-center font-medium border border-black px-2 py-2 lg:py-3 rounded-full w-[180px] lg:w-[200px] text-sm lg:text-base">${escape($_("about.right.top.header"))}</div> <p class="py-3 lg:py-4 text-base lg:text-lg font-medium w-full lg:w-[400px]">${escape($_("about.right.top.desc"))}</p> <h2 class="text-2xl lg:text-3xl font-semibold w-full lg:w-[420px]">${escape($_("about.right.top.title"))}</h2></div> <div class="relative h-[300px] sm:h-[350px] lg:h-[28vh]"><div class="absolute flex justify-center items-center -right-2 -bottom-2 bg-white rounded-full h-14 w-14 sm:h-16 sm:w-16 lg:h-20 lg:w-20 z-30"><div class="bg-black w-12 h-12 sm:w-14 sm:h-14 lg:w-16 lg:h-16 rounded-full flex justify-center items-center">${validate_component(Fa, "Fa").$$render(
    $$result,
    {
      icon: faArrowRight,
      class: "text-white text-xl sm:text-2xl"
    },
    {},
    {}
  )}</div></div> <div class="absolute p-6 lg:p-8 z-50"><div class="flex items-center justify-center font-medium border border-white text-white px-2 py-2 lg:py-3 rounded-full w-[180px] lg:w-[200px] text-sm lg:text-base">${escape($_("about.right.bottom.header"))}</div> <p class="py-3 lg:py-4 text-base lg:text-lg text-white font-medium w-full lg:w-2/3">${escape($_("about.right.top.desc"))}</p></div> <img src="img/carousel/2.jpg" class="rounded-[30px] lg:rounded-[40px] z-0 w-full h-full lg:w-[1150px] object-cover" alt="img-2"> <div class="absolute inset-0 bg-black opacity-40 z-20 rounded-[30px] lg:rounded-[40px] flex items-center justify-center" data-svelte-h="svelte-1j0ej07"></div></div></div></section>`;
});
const GallerySection = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let $_, $$unsubscribe__;
  $$unsubscribe__ = subscribe($format, (value) => $_ = value);
  $$unsubscribe__();
  return `<section class="flex flex-col xl:flex-row px-4 sm:px-10 lg:px-12 py-10 gap-10 xl:gap-16"><div class="w-full xl:flex-2 max-w-[100%] xl:max-w-[850px]" data-svelte-h="svelte-ofblwd"><img src="img/1.jpg" class="rounded-[30px] lg:rounded-[40px] w-full h-[300px] sm:h-[500px] lg:h-[700px] xl:h-[800px] 2xl:h-[900px] object-cover mx-auto" alt="img-2"></div> <div class="w-full xl:flex-1 flex items-center xl:-translate-y-12"><section class="px-4 sm:px-8 md:px-12 xl:px-0 bg-white text-black w-full"><div class="max-w-3xl 2xl:max-w-5xl mx-auto"><p class="text-base sm:text-lg md:text-xl uppercase tracking-wide mb-6 font-medium text-black">${escape($_("about-company.top.label"))}</p> <h1 class="text-4xl sm:text-6xl md:text-7xl xl:text-8xl font-medium leading-tight mb-6 mt-8">${escape($_("about-company.top.title"))}<br></h1> <p class="text-base sm:text-lg md:text-xl mb-8 w-full max-w-[90vw] md:max-w-[70vw] lg:max-w-[60vw] xl:max-w-[40vw] 2xl:max-w-[35vw]">${escape($_("about-company.middle.text"))}</p> <a href="#about" class="flex items-center text-sm lg:text-md gap-3 w-fit px-6 py-3 bg-black text-white font-medium rounded hover:bg-gray-900 transition">${escape($_("about-company.bottom.button"))} ${validate_component(Fa, "Fa").$$render(
    $$result,
    {
      icon: faArrowRight,
      class: "text-lg text-white lg:text-xl"
    },
    {},
    {}
  )}</a></div></section></div></section>`;
});
function is_date(obj) {
  return Object.prototype.toString.call(obj) === "[object Date]";
}
function cubicOut(t) {
  const f = t - 1;
  return f * f * f + 1;
}
function get_interpolator(a, b) {
  if (a === b || a !== a)
    return () => a;
  const type = typeof a;
  if (type !== typeof b || Array.isArray(a) !== Array.isArray(b)) {
    throw new Error("Cannot interpolate values of different type");
  }
  if (Array.isArray(a)) {
    const arr = b.map((bi, i) => {
      return get_interpolator(a[i], bi);
    });
    return (t) => arr.map((fn) => fn(t));
  }
  if (type === "object") {
    if (!a || !b)
      throw new Error("Object cannot be null");
    if (is_date(a) && is_date(b)) {
      a = a.getTime();
      b = b.getTime();
      const delta = b - a;
      return (t) => new Date(a + t * delta);
    }
    const keys = Object.keys(b);
    const interpolators = {};
    keys.forEach((key) => {
      interpolators[key] = get_interpolator(a[key], b[key]);
    });
    return (t) => {
      const result = {};
      keys.forEach((key) => {
        result[key] = interpolators[key](t);
      });
      return result;
    };
  }
  if (type === "number") {
    const delta = b - a;
    return (t) => a + t * delta;
  }
  throw new Error(`Cannot interpolate ${type} values`);
}
function tweened(value, defaults = {}) {
  const store = writable(value);
  let task;
  let target_value = value;
  function set(new_value, opts) {
    if (value == null) {
      store.set(value = new_value);
      return Promise.resolve();
    }
    target_value = new_value;
    let previous_task = task;
    let started = false;
    let {
      delay = 0,
      duration = 400,
      easing = identity,
      interpolate = get_interpolator
    } = assign(assign({}, defaults), opts);
    if (duration === 0) {
      if (previous_task) {
        previous_task.abort();
        previous_task = null;
      }
      store.set(value = target_value);
      return Promise.resolve();
    }
    const start = now() + delay;
    let fn;
    task = loop((now2) => {
      if (now2 < start)
        return true;
      if (!started) {
        fn = interpolate(value, new_value);
        if (typeof duration === "function")
          duration = duration(value, new_value);
        started = true;
      }
      if (previous_task) {
        previous_task.abort();
        previous_task = null;
      }
      const elapsed = now2 - start;
      if (elapsed > /** @type {number} */
      duration) {
        store.set(value = new_value);
        return false;
      }
      store.set(value = fn(easing(elapsed / duration)));
      return true;
    });
    return task.promise;
  }
  return {
    set,
    update: (fn, opts) => set(fn(target_value, value), opts),
    subscribe: store.subscribe
  };
}
const RealizationsSection = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  const rawStats = [
    {
      value: 500,
      label: "Products",
      suffix: "+"
    },
    {
      value: 20,
      label: "Projects",
      suffix: "+"
    },
    {
      value: 50,
      label: "Satisfied Customers",
      suffix: "+"
    },
    {
      value: 1,
      label: "Top 1 in Paris",
      suffix: "st"
    }
  ];
  const stores = rawStats.map(() => tweened(0, { duration: 1500, easing: cubicOut }));
  let values = stores.map(() => 0);
  stores.forEach((store, i) => {
    store.subscribe((val) => {
      values[i] = val;
    });
  });
  let sectionRef;
  return `<section class="py-16 bg-white"${add_attribute("this", sectionRef, 0)}><div class="container mx-auto px-12"><div class="flex justify-between flex-wrap gap-8">${each(rawStats, (stat, i) => {
    return `<div class="p-6"><p class="text-7xl lg:text-9xl font-medium text-black mb-2">${escape(Math.floor(values[i]))}${escape(stat.suffix)}</p> <p class="text-xl text-black opacity-50">${escape(stat.label)}</p> </div>`;
  })}</div></div></section>`;
});
const OurServise = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let $_, $$unsubscribe__;
  $$unsubscribe__ = subscribe($format, (value) => $_ = value);
  const sectionKeys = ["electricity", "plumbing", "insulation", "masonry", "flooring", "windows"];
  const images = [
    {
      image: "/img/ourservices/1.jpg",
      heightClass: "h-[240px] sm:h-[340px]"
    },
    {
      image: "/img/ourservices/2.jpg",
      heightClass: "h-[240px] sm:h-[700px]"
    },
    {
      image: "/img/ourservices/3.jpg",
      heightClass: "h-[240px] sm:h-[700px]"
    },
    {
      image: "/img/ourservices/4.jpg",
      heightClass: "h-[240px] sm:h-[340px]"
    },
    {
      image: "/img/ourservices/5.jpg",
      heightClass: "h-[240px] sm:h-[340px]"
    },
    {
      image: "/img/ourservices/6.jpg",
      heightClass: "h-[240px] sm:h-[700px]"
    }
  ];
  const items = sectionKeys.map((key, index) => ({
    key,
    image: images[index].image,
    heightClass: images[index].heightClass
  }));
  $$unsubscribe__();
  return `<section class="px-4 sm:px-8 md:px-12 pt-10 md:pt-16"><div class="flex flex-col lg:flex-row justify-between gap-6 mb-10"><h2 class="text-4xl md:text-5xl lg:text-7xl font-semibold lg:w-[40vw] leading-tight">${escape($_("our-services.title"))}</h2> <div class="flex-1 flex flex-col items-start lg:items-end justify-end"><button class="mb-4 flex items-center gap-2 text-sm md:text-base font-medium bg-black text-white px-4 lg:px-4 lg:py-2 rounded hover:bg-gray-800 transition">${escape($_("our-services.btn"))} ${validate_component(Fa, "Fa").$$render($$result, { icon: faArrowRight, class: "my-3.5" }, {}, {})}</button> <p class="text-left lg:text-right text-gray-600 w-full lg:w-[40vw] text-sm md:text-base">${escape($_("our-services.desc"))}</p></div></div>  <div class="columns-1 sm:columns-2 lg:columns-3 gap-6 space-y-6 pt-6">${each(items, (item) => {
    return `<div class="break-inside-avoid rounded-2xl overflow-hidden shadow hover:shadow-lg transition group relative"><div${add_attribute("class", `w-full bg-cover bg-center ${item.heightClass}`, 0)}${add_attribute("style", `background-image: url(${item.image});`, 0)}></div> <div class="absolute bottom-0 left-0 w-full h-1/2 bg-gradient-to-t from-black/80 to-transparent px-4 pb-4 text-white flex items-end"><h3 class="text-xl md:text-2xl font-medium">${escape($_(`our-services.sections.${item.key}.title`))}</h3></div> <div class="absolute bottom-4 right-4 bg-white p-3 md:p-4 text-black rounded-full group-hover:bg-gray-200 transition">${validate_component(Fa, "Fa").$$render($$result, { icon: faArrowRight }, {}, {})}</div> </div>`;
  })}</div></section>`;
});
const ContactSection = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let $_, $$unsubscribe__;
  $$unsubscribe__ = subscribe($format, (value) => $_ = value);
  let phoneButtonText = $_("contact.copy-btn");
  let emailButtonText = $_("contact.copy-btn");
  $$unsubscribe__();
  return `<section id="contact" class="px-4 sm:px-8 md:px-12 lg:px-16 my-16"><div class="flex flex-col lg:flex-row gap-6 mb-10"><div class="flex-1 flex flex-col items-start justify-start"><button class="mb-4 flex items-center gap-2 text-sm sm:text-md font-medium bg-black text-white px-4 sm:px-6 py-2 rounded hover:bg-gray-800 transition"><a href="mailto:k.p.batiment@gmail.com" class="flex items-center gap-2">${validate_component(Fa, "Fa").$$render($$result, { icon: faArrowRight, class: "my-1" }, {}, {})} ${escape($_("contact.title"))}</a></button> <p class="text-gray-600 w-full max-w-full sm:max-w-md text-sm sm:text-base">${escape($_("contact.desc"))}</p></div> <div class="flex-1 flex justify-start lg:justify-end"><h2 class="text-4xl sm:text-5xl lg:text-7xl font-semibold leading-tight text-left lg:text-right max-w-full lg:max-w-[50vw]">${escape($_("contact.desc2"))}</h2></div></div> <div class="pt-12"><div class="flex flex-col md:flex-row justify-between items-center gap-8 md:gap-4"><div class="flex flex-col justify-center h-auto md:h-[200px] rounded-[40px] w-full md:w-1/2"><p class="text-black text-2xl sm:text-3xl md:text-4xl lg:text-5xl">${escape($_("contact.phone"))}</p> <p class="font-bold text-left text-xl sm:text-2xl mt-2" data-svelte-h="svelte-18vfs20">+33 6 38 61 77 95</p> <button class="text-left text-base sm:text-lg w-fit cursor-pointer bg-black text-white px-4 sm:px-6 my-4 py-2 rounded hover:bg-gray-800 transition"${add_attribute("aria-label", $_("contact.copy-phone"), 0)}>${escape(phoneButtonText)}</button></div> <div class="flex flex-col justify-center items-end h-auto md:h-[200px] rounded-[40px] w-full md:w-1/2"><p class="text-black text-2xl sm:text-3xl md:text-4xl lg:text-5xl text-right">${escape($_("contact.email"))}</p> <p class="font-bold text-xl sm:text-2xl text-right mt-2" data-svelte-h="svelte-13moy7q">k.p.batiment@gmail.com</p> <button class="text-left text-base sm:text-lg w-fit cursor-pointer bg-black text-white px-4 sm:px-6 my-4 py-2 rounded hover:bg-gray-800 transition"${add_attribute("aria-label", $_("contact.copy-email"), 0)}>${escape(emailButtonText)}</button></div></div></div></section>`;
});
const _page_svelte_svelte_type_style_lang = "";
const css = {
  code: "@keyframes svelte-l2pwmm-spin-slow{from{transform:rotate(0deg)}to{transform:rotate(360deg)}}.animate-spin-slow.svelte-l2pwmm{animation:svelte-l2pwmm-spin-slow 50s linear infinite}",
  map: null
};
let text = "KPBAT •  Minimalist • Modern •";
const Page = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let $_, $$unsubscribe__;
  $$unsubscribe__ = subscribe($format, (value) => $_ = value);
  let { data } = $$props;
  let width;
  let slides = data.slides;
  let splideRef;
  let intervalId;
  let options = {
    type: "loop",
    rewind: true,
    autoplay: false,
    arrows: true
  };
  onDestroy(() => {
    clearInterval(intervalId);
  });
  let repeatedText = Array(5).fill(text).join(" ");
  if ($$props.data === void 0 && $$bindings.data && data !== void 0)
    $$bindings.data(data);
  $$result.css.add(css);
  let $$settled;
  let $$rendered;
  do {
    $$settled = true;
    options.arrows = width > 768;
    $$rendered = `<main class="relative z-0 h-screen md:h-[90vh] mb-6 w-[90vw] mx-auto md:w-screen flex justify-center items-center"><div class="w-full h-full md:-h-[15vh] md:w-[95vw]"><div class="absolute top-[40vh] left-1/2 -translate-x-1/2 -translate-y-1/2 z-10 text-center"><h1 class="text-white text-2xl font-bold md:text-4xl lg:text-7xl whitespace-nowrap">${escape($_("header.main"))}</h1> <h2 class="text-white text-base md:text-xl lg:text-2xl opacity-80">${escape($_("header.bottom"))}</h2></div> <div class="hidden lg:inline lg:absolute bottom-24 right-24 z-10 w-64 h-64 items-center justify-center"><svg viewBox="0 0 100 100" class="w-full h-full animate-spin-slow svelte-l2pwmm"><defs><path id="circlePath" d="M 50,50 m -35,0 a 35,35 0 1,1 70,0 a 35,35 0 1,1 -70,0"></path></defs><text font-size="7" fill="white" font-weight="600"><textPath href="#circlePath" startOffset="0%">${escape(repeatedText)}</textPath></text></svg></div> <div class="hidden lg:inline lg:absolute bottom-24 left-24 z-10 border text-white p-6 text-md border-opacity-5 bg-shadow border-shadow backdrop-blur-2xl xl:w-[30vw] rounded-xl"><p>${escape($_("header.contact.text"))}</p> <button class="flex items-center gap-4 bg-black px-4 rounded-xl text-md mt-3">${escape($_("header.contact.btn"))} ${validate_component(Fa, "Fa").$$render(
      $$result,
      {
        icon: faArrowRight,
        class: "m-auto my-3.5"
      },
      {},
      {}
    )}</button></div> ${validate_component(Splide_1, "Splide").$$render(
      $$result,
      { options, this: splideRef },
      {
        this: ($$value) => {
          splideRef = $$value;
          $$settled = false;
        }
      },
      {
        default: () => {
          return `${each(slides, (slide) => {
            return `${validate_component(SplideSlide, "SplideSlide").$$render(
              $$result,
              {
                class: "overflow-hidden rounded-[40px] md:mt-4 h-screen w-[80vw] md:h-[85vh] md:w-[95vw]"
              },
              {},
              {
                default: () => {
                  return `<img${add_attribute("src", slide.src, 0)}${add_attribute("alt", slide.alt, 0)} aria-label="img-main" class="brightness-50 w-full h-full object-cover bg-center"> `;
                }
              }
            )}`;
          })}`;
        }
      }
    )}</div></main> ${validate_component(AboutSection, "About").$$render($$result, {}, {}, {})} ${validate_component(RealizationsSection, "RealizationsSection").$$render($$result, {}, {}, {})} ${validate_component(GallerySection, "GallerySection").$$render($$result, {}, {}, {})} ${validate_component(OurServise, "OurServise").$$render($$result, {}, {}, {})} ${validate_component(ContactSection, "ContactSection").$$render($$result, {}, {}, {})} `;
  } while (!$$settled);
  $$unsubscribe__();
  return $$rendered;
});
export {
  Page as default
};
