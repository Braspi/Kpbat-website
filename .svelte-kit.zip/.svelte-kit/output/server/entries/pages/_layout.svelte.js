import { c as create_ssr_component, a as subscribe, o as onDestroy, e as escape, v as validate_component, b as each, d as add_attribute } from "../../chunks/ssr.js";
import { a as addMessages, i as init, $ as $format } from "../../chunks/runtime.esm.js";
import { F as Fa } from "../../chunks/fa.js";
import { faBars } from "@fortawesome/free-solid-svg-icons";
import { p as page } from "../../chunks/stores.js";
const app = "";
const splide_min = "";
const header$1 = {
  main: "We'll find a solution",
  bottom: "Clearly the best renovation company in the market.",
  contact: {
    text: "Looking to give your home a fresh new look? Trust KP BAT for all your renovation needs. Our experienced team offers services ranging from simple painting updates to full-scale renovations, ensuring your vision comes to life with quality and precision.",
    btn: "Contact now!"
  }
};
const nav$1 = {
  gallery: "Gallery",
  home: "Home",
  contact: "Contact",
  language: "Choose language"
};
const about$1 = {
  left: {
    first: "Modern",
    last: "Minimalist"
  },
  right: {
    top: {
      header: "Elegant Renovation",
      desc: "Thoughtfully designed spaces where every detail works in harmony",
      title: "Make your home a style gallery"
    },
    bottom: {
      header: "Refined Renovations",
      desc: "Experience beauty in every detail of your renewed space"
    }
  }
};
const services$1 = {
  header: "Our Services",
  description: "We provide services and products that set high standards for quality, reliability, durability.",
  sections: {
    electricity: {
      title: "Electricity",
      description: "Vous recherchez un professionnel pour une mise aux normes électrique ? Faites de notre\nentreprise pour les travaux d’électricité générale de votre maison ou de votre appartement.\nNous intervenons en neuf comme en rénovation :\nConception et installation électrique neuve\nRénovation de l’électricité de votre habitation\nMise en conformité des installations électriques\nEntretien et dépannage en électricité\nMise en service de VMC, Interphone"
    },
    plumbing: {
      title: "Plumbing/Heating",
      description: "S'occupe de vous fournir et de venir installer votre plomberie et vos sanitaires\nque ce soit pour un usage privatif ou professionnel, en même temps s&#39;occupe\nde vous fournir et de venir installer vos chaudières, chauffe-eaux et radiateurs."
    },
    insulation: {
      title: "Interior/Exterior",
      description: "Effectue vos travaux d’isolation des murs par l’intérieur. Cette technique\nconsiste à ajouter de l’isolant (laine de verre, de roche, de liège, chanvre) à\nl’intérieur de la maison.\nNous intervenons également dans l’isolation des murs par l’extérieur. Cela\nconsiste à installer des panneaux isolants à l’extérieur de l’ensemble de la\nmaison. les isolants synthétiques (en plastique), les isolants naturels (produits\nvégétaux ou animaux, comme la laine de mouton) et les isolants minéraux,\ncomme la laine de verre."
    },
    masonry: {
      title: "Masonry",
      description: "Nous nous spécialisons dans Artisan maçon, Ouverture, Renforcement, Dalles\net chapes, Démolition, Travail de la pierre, Murs porteurs, Fondations,\nCouverture, Ouvertures de murs, Charpente. Notre offre comprend également\ndes consultations avec l&#39;Ingénieur"
    },
    flooring: {
      title: "Flooring",
      description: "Notre équipe prendra soin de votre sol. On peut parler de carrelage, parquet,\nsol lino, sol PVC, Moquette, Béton Cire... Nous veillerons à la bonne\npréparation des surfaces, à l&#39;adéquation du matériau, au respect"
    },
    windows: {
      title: "Windows",
      description: "La fenêtre joue un rôle essentiel et est un en élément clé de votre habitation. Toutes nos\nfenêtres, sont personnalisables (couleurs, formes, sens d&#39;ouvertures). Votre fenêtre s’intègre\nà votre façade et contribue à l&#39;harmonie de votre habitation.\n\nQue ce soit sur PVC, Bois, Aluminium ou Bois-Alu, vous pouvez choisir parmi de nombreux\nstyles, options et accessoires. Succombez également à la praticité du volet roulant, réalisez\nde belles économies d’énergie, gagnez en confort et sécurité."
    }
  }
};
const contact$1 = {
  title: "Contact",
  desc: "Have a question or a project in mind? We're here to help, feel free to reach out and we'll get back to you as soon as possible.\n",
  desc2: "Let’s build something great together\n",
  phone: "Phone Number",
  email: "Email Address",
  "copy-phone": "Copy phone number",
  "copy-email": "Copy email address",
  "copy-btn": "Copy",
  "copied-btn": "Copied!"
};
const form$1 = {
  header: "Get in Touch with Us",
  description: "If you have any questions, please write to us!",
  form: {
    title: "Contact Us",
    description: "Our contact form",
    name: "Name",
    surname: "Last Name",
    email: "Email",
    phone: "Phone",
    message: "Message",
    privacy: "By checking this box, you agree to our",
    "privacy-link": "privacy policy",
    "privacy-notification": "You must agree to our privacy policy!",
    submit: "Submit"
  },
  details: {
    title: "Contact details",
    description: "Our contact data",
    phone: "Contact telephone",
    email: "Contact email"
  }
};
const footer$1 = {
  title: "Engage with Us in Conversation.\n",
  desc: "In a global world based on communication, a brand must look beyond its borders, open up to new experiences, and dare to be different. Meeting the brightest minds of one's time is the most effective way to nurture creativity.",
  contact: "Contact",
  customer: "Customer Service",
  media: "Social Media"
};
const gallery$1 = {
  header: "Select categories",
  description: "Browse our gallery, and see why we're worthy of your trust!"
};
const en = {
  header: header$1,
  nav: nav$1,
  about: about$1,
  "about-old": {
    name: "Who are we?",
    header: "Our company specializes in renovation.",
    line1: "Are you looking to renovate your interior to give a new life to your house or apartment? Trust KP BAT.",
    line2: "We provide you with a team of qualified and experienced professionals to carry out all your renovation projects, from simple painting refreshes to complete renovations.",
    line3: "We offer a wide range of services to meet all your needs: painting, flooring, plumbing, electricity, carpentry, kitchen and bathroom design, etc.",
    line4: "We work with high-quality materials to ensure a durable and aesthetic result. We listen to your needs and expectations to offer you a tailor-made service that is adapted to your budget and constraints."
  },
  "about-company": {
    top: {
      title: "Transform Your Interior",
      label: "Expertise • Renovation"
    },
    middle: {
      text: "Give a new life to your house or apartment with our skilled team. KP BAT supports you in all your renovation projects: painting, electricity, plumbing, carpentry, custom kitchens and bathrooms."
    },
    bottom: {
      button: "About Us"
    }
  },
  "our-services": {
    title: "Explore Our Expert Services",
    desc: "We provide services and products that set high standards for quality, reliability, and durability, ensuring long-term value and exceptional performance in every detail.",
    btn: "View More",
    sections: {
      electricity: {
        title: "Electricity",
        description: "Are you looking for a professional to bring your electrical installation up to standard? Trust our company for all general electrical work in your house or apartment. We work on both new builds and renovations:\n- Design and installation of new electrical systems\n- Renovation of existing electrical installations\n- Compliance upgrades\n- Electrical maintenance and troubleshooting\n- Commissioning of VMC systems and intercoms"
      },
      plumbing: {
        title: "Plumbing/Heating",
        description: "We supply and install plumbing and sanitary equipment for both private and professional use. At the same time, we take care of delivering and installing your boilers, water heaters, and radiators."
      },
      insulation: {
        title: "Interior/Exterior",
        description: "We carry out wall insulation work from the inside, which involves adding insulation (glass wool, rock wool, cork, hemp) inside the house.\nWe also handle exterior wall insulation by installing insulating panels on the entire outer surface of the house. These include synthetic (plastic) insulators, natural ones (plant- or animal-based like sheep's wool), and mineral types like glass wool."
      },
      masonry: {
        title: "Masonry",
        description: "We specialize in artisan masonry, wall openings, reinforcement, slabs and screeds, demolition, stonework, load-bearing walls, foundations, roofing, structural openings, and carpentry. Our offer also includes consultations with an engineer."
      },
      flooring: {
        title: "Flooring",
        description: "Our team takes great care of your flooring. Whether it’s tiling, parquet, linoleum, PVC flooring, carpet, or polished concrete, we ensure proper surface preparation, material compatibility, and workmanship quality."
      },
      windows: {
        title: "Windows",
        description: "Windows play a key role and are an essential element of your home. All our windows are fully customizable (colours, shapes, opening directions). They blend seamlessly with your façade and contribute to the harmony of your home.\n\nWhether in PVC, wood, aluminium, or wood-aluminium, you can choose from many styles, options, and accessories. Opt for practical roller shutters to improve comfort, increase energy savings, and enhance security."
      }
    }
  },
  "gallery-sec": {
    header: "Our lastest works",
    description: "Browse our gallery, and see why we're worthy of your trust!",
    btn: "Check All"
  },
  services: services$1,
  contact: contact$1,
  form: form$1,
  footer: footer$1,
  gallery: gallery$1
};
const header = {
  main: "On trouvera une solution",
  bottom: "Clairement la meilleure entreprise de rénovation du marché.",
  contact: {
    text: "Vous souhaitez donner un nouveau look à votre maison ? Faites confiance à KP BAT pour tous vos besoins en rénovation. Notre équipe expérimentée propose des services allant de simples retouches de peinture à des rénovations complètes, garantissant que votre vision prenne vie avec qualité et précision.",
    btn: "Contactez-nous!"
  }
};
const nav = {
  gallery: "Galerie",
  home: "Accueil",
  contact: "Contact",
  language: "Choisissez la langue"
};
const about = {
  left: {
    first: "Moderne",
    last: "Minimaliste"
  },
  right: {
    top: {
      header: "Rénovation Élégante",
      desc: "Des espaces pensés où chaque détail fonctionne en harmonie",
      title: "Transformez votre maison en galerie de style"
    },
    bottom: {
      header: "Rénovations Raffinées",
      desc: "Découvrez la beauté de chaque détail de votre espace renouvelé"
    }
  }
};
const services = {
  header: "Nos services",
  description: "Nous fournissons des services et des produits qui établissent des normes élevées de qualité, de fiabilité et de durabilité.",
  sections: {
    electricity: {
      title: "Électricité",
      description: "Vous recherchez un professionnel pour une mise aux normes électrique ? Faites de notre\nentreprise pour les travaux d’électricité générale de votre maison ou de votre appartement.\nNous intervenons en neuf comme en rénovation :\nConception et installation électrique neuve\nRénovation de l’électricité de votre habitation\nMise en conformité des installations électriques\nEntretien et dépannage en électricité\nMise en service de VMC, Interphone"
    },
    plumbing: {
      title: "Plomberie/Chauffage",
      description: "S'occupe de vous fournir et de venir installer votre plomberie et vos sanitaires\nque ce soit pour un usage privatif ou professionnel, en même temps s’occupe\nde vous fournir et de venir installer vos chaudières, chauffe-eaux et radiateurs."
    },
    insulation: {
      title: "Interieure/Exterieure",
      description: "Effectue vos travaux d’isolation des murs par l’intérieur. Cette technique\nconsiste à ajouter de l’isolant (laine de verre, de roche, de liège, chanvre) à\nl’intérieur de la maison.\nNous intervenons également dans l’isolation des murs par l’extérieur. Cela\nconsiste à installer des panneaux isolants à l’extérieur de l’ensemble de la\nmaison. les isolants synthétiques (en plastique), les isolants naturels (produits\nvégétaux ou animaux, comme la laine de mouton) et les isolants minéraux,\ncomme la laine de verre."
    },
    masonry: {
      title: "Maçonnerie",
      description: "Nous nous spécialisons dans Artisan maçon, Ouverture, Renforcement, Dalles\net chapes, Démolition, Travail de la pierre, Murs porteurs, Fondations,\nCouverture, Ouvertures de murs, Charpente. Notre offre comprend également\ndes consultations avec l’Ingénieur"
    },
    flooring: {
      title: "Revetement de sol",
      description: "Notre équipe prendra soin de votre sol. On peut parler de carrelage, parquet,\nsol lino, sol PVC, Moquette, Béton Cire... Nous veillerons à la bonne\npréparation des surfaces, à l’adéquation du matériau, au respect"
    },
    windows: {
      title: "Fenêtre",
      description: "La fenêtre joue un rôle essentiel et est un en élément clé de votre habitation. Toutes nos\nfenêtres, sont personnalisables (couleurs, formes, sens d’ouvertures). Votre fenêtre s’intègre\nà votre façade et contribue à l’harmonie de votre habitation.\n\nQue ce soit sur PVC, Bois, Aluminium ou Bois-Alu, vous pouvez choisir parmi de nombreux\nstyles, options et accessoires. Succombez également à la praticité du volet roulant, réalisez\nde belles économies d’énergie, gagnez en confort et sécurité."
    }
  }
};
const contact = {
  title: "Contact",
  desc: "Vous avez une question ou un projet en tête ? Nous sommes là pour vous aider, n'hésitez pas à nous contacter et nous vous répondrons dans les plus brefs délais.",
  desc2: "Construisons quelque chose de grand ensemble",
  phone: "Numéro de téléphone",
  email: "Adresse e-mail",
  "copy-phone": "Copier le numéro de téléphone",
  "copy-email": "Copier l'adresse e-mail",
  "copy-btn": "Copie",
  "copied-btn": "Copié!"
};
const form = {
  header: "Envoyez-nous un message",
  description: "Si vous avez un problème, écrivez-nous!",
  form: {
    title: "Contactez-nous",
    description: "Notre formulaire de contact",
    name: "Prénom",
    surname: "Nom",
    email: "E-mail",
    phone: "Téléphone",
    message: "Message",
    privacy: "En cochant cette case, vous acceptez notre",
    "privacy-link": "politique de confidentialité",
    "privacy-notification": "Vous devez accepter notre politique de confidentialité!",
    submit: "Envoyer"
  },
  details: {
    title: "Contactez-nous",
    description: "Détails du contact",
    phone: "Contact par téléphone",
    email: "Contact par e-mail"
  }
};
const footer = {
  title: "Engagez la conversation avec nous.\n",
  desc: "Dans un monde global fondé sur la communication, une marque doit dépasser ses frontières, s’ouvrir à de nouvelles expériences et oser être différente. Rencontrer les esprits les plus brillants de son époque est la manière la plus efficace de nourrir la créativité.",
  contact: "Contact",
  customer: "Service Client",
  media: "Réseaux Sociaux"
};
const gallery = {
  header: "Sélectionnez les catégories",
  description: "Parcourez notre galerie et voyez pourquoi nous méritons votre confiance"
};
const fr = {
  header,
  nav,
  about,
  "about-old": {
    name: "Oui sommes nous?",
    header: "Votre entreprise spécialisée dans la rénovation.",
    line1: "Vous cherchez à rénover votre intérieur pour donner une nouvelle vie à votre maison ou votre appartement ? Faites confiance à KP BAT.",
    line2: "Nous mettons à votre disposition une équipe de professionnels qualifiés et expérimentés pour réaliser tous vos projets de rénovation, du simple rafraîchissement de peinture à la rénovation complète.",
    line3: "Nous vous proposons une large gamme de services pour répondre à tous vos besoins peinture, revêtement de sol, plomberie, électricité, menuiserie, aménagement de cuisine et salle de bain, etc.",
    line4: "Nous travaillons avec des matériaux de qualité supérieure pour garantir un résultat durable et esthétique. Nous sommes à l'écoute de vos besoins et de vos attentes pour vous offrir une prestation sur mesure, adaptée à votre budget et à vos contraintes."
  },
  "about-company": {
    top: {
      title: "Transformez Votre Intérieur",
      label: "Expertise • Rénovation"
    },
    middle: {
      text: "Donnez une nouvelle vie à votre maison ou appartement avec notre équipe qualifiée. KP BAT vous accompagne dans tous vos projets de rénovation : peinture, électricité, plomberie, menuiserie, cuisines et salles de bains sur mesure."
    },
    bottom: {
      button: "À Propos de Nous"
    }
  },
  "our-services": {
    title: "Découvrez nos services d'experts",
    desc: "Nous proposons des services et produits qui répondent aux plus hauts standards en matière de qualité, de fiabilité et de durabilité, garantissant une valeur à long terme et des performances exceptionnelles dans les moindres détails.",
    btn: "Voir plus",
    sections: {
      electricity: {
        title: "Électricité",
        description: "Vous recherchez un professionnel pour la mise aux normes de votre installation électrique ? Faites appel à notre entreprise pour tous vos travaux d’électricité générale, en maison ou en appartement. Nous intervenons en neuf comme en rénovation :\n- Conception et installation électrique neuve\n- Rénovation des installations existantes\n- Mise en conformité\n- Entretien et dépannage électrique\n- Mise en service de VMC et interphones"
      },
      plumbing: {
        title: "Plomberie / Chauffage",
        description: "Nous nous occupons de la fourniture et de l’installation de votre plomberie et de vos équipements sanitaires, que ce soit pour un usage privé ou professionnel. Nous assurons également la pose de chaudières, chauffe-eaux et radiateurs."
      },
      insulation: {
        title: "Isolation intérieure/extérieure",
        description: "Nous réalisons l’isolation des murs par l’intérieur, qui consiste à ajouter des matériaux isolants (laine de verre, laine de roche, liège, chanvre) à l’intérieur de votre maison.\nNous intervenons aussi pour l’isolation par l’extérieur, en installant des panneaux isolants tout autour de la maison. Cela inclut des isolants synthétiques (plastique), naturels (végétaux ou animaux comme la laine de mouton), et minéraux comme la laine de verre."
      },
      masonry: {
        title: "Maçonnerie",
        description: "Nous sommes spécialisés dans la maçonnerie artisanale, les ouvertures, les renforcements, les dalles et chapes, la démolition, le travail de la pierre, les murs porteurs, les fondations, la couverture, les ouvertures structurelles et la charpente. Nous proposons également des consultations avec un ingénieur."
      },
      flooring: {
        title: "Revêtements de sol",
        description: "Notre équipe prendra soin de vos sols : carrelage, parquet, lino, sol PVC, moquette ou béton ciré. Nous veillons à une bonne préparation des surfaces, au choix du matériau adapté et à une exécution soignée."
      },
      windows: {
        title: "Fenêtres",
        description: "La fenêtre est un élément essentiel de votre habitation. Toutes nos fenêtres sont personnalisables (couleurs, formes, sens d’ouverture) pour s’intégrer parfaitement à votre façade et renforcer l’harmonie de votre maison.\n\nQue ce soit en PVC, bois, aluminium ou bois-alu, vous pouvez choisir parmi de nombreux styles, options et accessoires. Optez également pour la praticité des volets roulants pour réaliser des économies d’énergie, améliorer votre confort et renforcer votre sécurité."
      }
    }
  },
  "gallery-sec": {
    header: "Découvrez nos dernières réalisations!",
    description: "Parcourez notre galerie et voyez pourquoi nous méritons votre confiance",
    btn: "Vérifie tout"
  },
  services,
  contact,
  form,
  footer,
  gallery
};
addMessages("en", en);
addMessages("fr", fr);
init({
  fallbackLocale: "fr",
  initialLocale: "fr"
});
const Nav = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let $$unsubscribe_page;
  let $_, $$unsubscribe__;
  $$unsubscribe_page = subscribe(page, (value) => value);
  $$unsubscribe__ = subscribe($format, (value) => $_ = value);
  onDestroy(() => {
    if (typeof document !== "undefined") {
      document.body.classList.remove("overflow-hidden");
    }
  });
  {
    if (typeof document !== "undefined") {
      {
        document.body.classList.remove("overflow-hidden");
      }
    }
  }
  $$unsubscribe_page();
  $$unsubscribe__();
  return `<div id="nav" class="w-full h-24 relative top-0 z-10 transition duration-500 md:h-[85px] text-black flex items-center justify-between px-4 md:px-11"><a href="/" class="flex items-center" data-svelte-h="svelte-vcp6a9"><img src="/icon/logo/LOGO2-black-alpha.png" alt="logo" class="select-none h-[75px] -translate-x-4 md:-translate-x-0 ml-6 md:h-[92px]"></a> <div class="flex gap-6 items-center"><div class="hidden md:flex space-x-8 text-xl font-medium opacity-80"><a href="/" class="no-underline hover:text-hoverColor transition duration-100">${escape($_("nav.home"))}</a> <a href="/gallery" class="no-underline hover:text-hoverColor transition duration-100">${escape($_("nav.gallery"))}</a> <a href="/#contact" class="no-underline hover:text-hoverColor transition duration-100">${escape($_("nav.contact"))}</a></div> <div class="border-r border-opacity-30 border-black h-8"></div> <div class="hidden md:flex space-x-2"><div role="button" tabindex="0" class="w-14 h-9 p-1.5 cursor-pointer select-none hover:brightness-50 transition duration-100" data-svelte-h="svelte-1kp7rjf"><img src="/icon/flags/france.webp" alt="france-flag" class="w-full h-full"></div> <div role="button" tabindex="0" class="w-14 h-9 p-1.5 cursor-pointer select-none hover:brightness-50 transition duration-100" data-svelte-h="svelte-xgeo16"><img src="/icon/flags/united_kingdom.webp" alt="english-flag" class="w-full h-full"></div></div></div> <div class="block md:hidden cursor-pointer -translate-x-6 translate-y-1" role="button" tabindex="0">${validate_component(Fa, "Fa").$$render($$result, { icon: faBars, size: "2x" }, {}, {})}</div> ${``}</div>  `;
});
const Footer = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let $_, $$unsubscribe__;
  $$unsubscribe__ = subscribe($format, (value) => $_ = value);
  const footerSections = [
    {
      title: $_("footer.contact"),
      links: [
        { name: "+33 6 38 61 77 95", href: "#" },
        {
          name: "k.p.batiment@gmail.com",
          href: "#"
        }
      ]
    },
    {
      title: "Customer Service",
      links: [
        {
          name: "Privacy Policy",
          href: "https://docs.google.com/document/d/1bnxOXVHx54XLblR6ZMMVRtHaewmt3CC4fmrkdvxEdEA/edit"
        }
      ]
    },
    {
      title: "Social Media",
      links: [
        {
          name: "Instagram",
          href: "https://www.instagram.com/kp_bat/"
        },
        {
          name: "Facebook",
          href: "https://www.facebook.com/kpbat"
        },
        {
          name: "Pinterest",
          href: "https://fr.pinterest.com/kp_bat/"
        }
      ]
    }
  ];
  $$unsubscribe__();
  return `<footer class="bg-black text-white py-12 px-4 sm:px-6 lg:px-8"><div class="max-w-screen-xl mx-auto px-4 sm:px-6 lg:px-8"><div class="flex flex-col lg:flex-row gap-10 lg:gap-20 items-center"><div class="lg:flex-1 w-full"><h2 class="text-4xl md:text-5xl lg:text-7xl font-bold mb-6 lg:mb-8">${escape($_("footer.title"))}</h2> <p class="text-white text-sm md:text-base mb-10 max-w-3xl">${escape($_("footer.desc"))}</p></div> <div class="w-full lg:w-[500px] flex-shrink-0" data-svelte-h="svelte-1burgrd"><img src="/img/carousel/1.jpg" alt="img-2" class="rounded-[20px] md:rounded-[30px] lg:rounded-[40px] w-full object-cover h-[250px] md:h-[350px] lg:h-[100%]"></div></div> <div class="mt-16 flex flex-col lg:flex-row justify-between gap-10"><div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-8 flex-1">${each(footerSections, (section) => {
    return `<div><h3 class="text-lg font-semibold mb-4">${escape(section.title)}</h3> <ul class="space-y-2">${each(section.links, (link) => {
      return `<li><a${add_attribute("href", link.href, 0)} class="text-white hover:text-opacity-70 text-sm">${escape(link.name)}</a> </li>`;
    })}</ul> </div>`;
  })}</div> <div class="flex flex-col items-center lg:items-end text-center lg:text-right"><p class="text-5xl md:text-7xl font-bold" data-svelte-h="svelte-1e79esz">KPBAT</p> <p class="text-sm md:text-base">© 2022 - ${escape((/* @__PURE__ */ new Date()).getFullYear())} KP BAT. All Rights Reserved</p> <span class="opacity-70 text-sm" data-svelte-h="svelte-39kj2s">Design and code - <a href="https://github.com/Braspi/" class="underline">Jeremiasz Cz.</a></span> <p class="opacity-70 text-xs" data-svelte-h="svelte-1mlew54">last update - 2025</p></div></div></div></footer>`;
});
const Layout = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  return `${validate_component(Nav, "Nav").$$render($$result, {}, {}, {})} ${slots.default ? slots.default({}) : ``} ${validate_component(Footer, "Footer").$$render($$result, {}, {}, {})}`;
});
export {
  Layout as default
};
