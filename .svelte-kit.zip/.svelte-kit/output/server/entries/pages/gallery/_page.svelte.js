import { c as create_ssr_component, a as subscribe, e as escape, b as each } from "../../../chunks/ssr.js";
import { $ as $format } from "../../../chunks/runtime.esm.js";
import { c as categories } from "../../../chunks/store.js";
const Page = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let $_, $$unsubscribe__;
  let $categories, $$unsubscribe_categories;
  $$unsubscribe__ = subscribe($format, (value) => $_ = value);
  $$unsubscribe_categories = subscribe(categories, (value) => $categories = value);
  $$unsubscribe__();
  $$unsubscribe_categories();
  return `<section class="min-h-screen pb-24 bg-light"><div class="relative z-0 top-20 lg:top-24"><div class="m-auto my-10 text-center text-dark"><h2 class="text-3xl md:text-4xl lg:text-5xl font-light ">${escape($_("gallery.header"))}</h2> <h3 class="text-md md:text-xl lg:text-2xl whitespace-normal">${escape($_("gallery.description"))}</h3></div> <div class="flex flex-wrap gap-6 md:gap-10 m-auto justify-center pb-8 lg:pb-12">${each($categories, (category) => {
    return `<div class="relative w-[80%] lg:w-[40%] xl:w-[25%] shadow-lg hover:scale-95 transition-transform duration-200"><a href="${"/gallery/images/?id=" + escape(category.id, true)}"><img src="${"https://api.kpbat.com/resources/category_" + escape(category.id, true) + "/" + escape(category.primary_image, true)}" alt="test" class="w-full max-h-80 object-cover"> <div class="absolute inset-0 bg-white opacity-50"></div> <div class="absolute inset-0 flex items-center justify-center"><p class="text-center text-2xl z-10 lg:text-3xl">${escape(category.display_name)}</p> </div></a> </div>`;
  })}</div>       </div></section>`;
});
export {
  Page as default
};
