import { c as create_ssr_component, a as subscribe, e as escape, v as validate_component, b as each, d as add_attribute } from "../../../../chunks/ssr.js";
import { S as Splide_1, a as SplideSlide } from "../../../../chunks/SplideSlide.js";
import { p as page } from "../../../../chunks/stores.js";
import { a as categoryName, i as isLoading, b as images } from "../../../../chunks/store.js";
const Page = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let $$unsubscribe_page;
  let $categoryName, $$unsubscribe_categoryName;
  let $isLoading, $$unsubscribe_isLoading;
  let $images, $$unsubscribe_images;
  $$unsubscribe_page = subscribe(page, (value) => value);
  $$unsubscribe_categoryName = subscribe(categoryName, (value) => $categoryName = value);
  $$unsubscribe_isLoading = subscribe(isLoading, (value) => $isLoading = value);
  $$unsubscribe_images = subscribe(images, (value) => $images = value);
  let main;
  let thumbs;
  const mainOptions = {
    type: "loop",
    perPage: 1,
    perMove: 0,
    gap: "1rem",
    pagination: false,
    width: "100vh"
  };
  const thumbsOptions = {
    type: "loop",
    rewind: true,
    gap: "1rem",
    pagination: false,
    fixedWidth: 110,
    fixedHeight: 70,
    cover: true,
    focus: "center",
    isNavigation: true,
    arrows: false,
    width: "80vh"
  };
  let $$settled;
  let $$rendered;
  do {
    $$settled = true;
    $$rendered = `<section class="min-h-screen bg-light"><div class="relative z-0 top-20 lg:top-24"><div class="m-auto my-10 text-center text-dark"><h2 class="text-3xl md:text-4xl lg:text-5xl font-normal">${escape($categoryName)}</h2></div></div> <div class="pt-20 flex items-center justify-center">${!$isLoading ? `<div class="wrapper">${validate_component(Splide_1, "Splide").$$render(
      $$result,
      {
        options: mainOptions,
        "aria-labelledby": "thumbnails-example-heading",
        class: "w-full mx-auto",
        this: main
      },
      {
        this: ($$value) => {
          main = $$value;
          $$settled = false;
        }
      },
      {
        default: () => {
          return `${each($images, (slide) => {
            return `${validate_component(SplideSlide, "SplideSlide").$$render($$result, {}, {}, {
              default: () => {
                return `<img${add_attribute("src", slide.src, 0)}${add_attribute("alt", slide.alt, 0)} class="max-h-128 mx-auto object-cover"> `;
              }
            })}`;
          })}`;
        }
      }
    )} ${validate_component(Splide_1, "Splide").$$render(
      $$result,
      {
        options: thumbsOptions,
        class: "pt-4 mx-auto",
        this: thumbs
      },
      {
        this: ($$value) => {
          thumbs = $$value;
          $$settled = false;
        }
      },
      {
        default: () => {
          return `${each($images, (slide) => {
            return `${validate_component(SplideSlide, "SplideSlide").$$render($$result, {}, {}, {
              default: () => {
                return `<img${add_attribute("src", slide.src, 0)}${add_attribute("alt", slide.alt, 0)}> `;
              }
            })}`;
          })}`;
        }
      }
    )}</div>` : `<p class="text-4xl" data-svelte-h="svelte-5ha929">loading...</p>`}</div></section>`;
  } while (!$$settled);
  $$unsubscribe_page();
  $$unsubscribe_categoryName();
  $$unsubscribe_isLoading();
  $$unsubscribe_images();
  return $$rendered;
});
export {
  Page as default
};
