import { w as writable } from "./index.js";
const categories = writable([]);
const images = writable([]);
const categoryName = writable("");
const isLoading = writable(true);
export {
  categoryName as a,
  images as b,
  categories as c,
  isLoading as i
};
