export const manifest = (() => {
function __memo(fn) {
	let value;
	return () => value ??= (value = fn());
}

return {
	appDir: "_app",
	appPath: "_app",
	assets: new Set(["favicon.ico","icon/flags/france.webp","icon/flags/united_kingdom.webp","icon/logo/LOGO1.jpg","icon/logo/LOGO1_alpha.png","icon/logo/LOGO2-black-alpha.png","icon/logo/LOGO2.jpg","icon/logo/LOGO2_alpha.png","icon/logo/LOGO3.jpg","img/.DS_Store","img/1.jpg","img/carousel/1.jpg","img/carousel/2.jpg","img/carousel/3.jpg","img/carousel/4.jpg","img/carousel/5.jpg","img/carousel/6.jpg","img/carousel/7.jpg","img/gallery/1.jpg","img/gallery/2.jpg","img/gallery/3.jpg","img/gallery/4.jpg","img/gallery/5.jpg","img/gallery/6.jpg","img/ourservices/1.jpg","img/ourservices/2.jpg","img/ourservices/3.jpg","img/ourservices/4.jpg","img/ourservices/5.jpg","img/ourservices/6.jpg","robots.txt","sitemap.xml"]),
	mimeTypes: {".ico":"image/vnd.microsoft.icon",".webp":"image/webp",".jpg":"image/jpeg",".png":"image/png",".txt":"text/plain",".xml":"application/xml"},
	_: {
		client: {"start":"_app/immutable/entry/start.69badb6f.js","app":"_app/immutable/entry/app.8922ec6f.js","imports":["_app/immutable/entry/start.69badb6f.js","_app/immutable/chunks/scheduler.e1743921.js","_app/immutable/chunks/singletons.0caa2a30.js","_app/immutable/chunks/index.805014c1.js","_app/immutable/entry/app.8922ec6f.js","_app/immutable/chunks/scheduler.e1743921.js","_app/immutable/chunks/index.0f4af11a.js"],"stylesheets":[],"fonts":[]},
		nodes: [
			__memo(() => import('./nodes/0.js')),
			__memo(() => import('./nodes/1.js')),
			__memo(() => import('./nodes/2.js')),
			__memo(() => import('./nodes/3.js')),
			__memo(() => import('./nodes/4.js')),
			__memo(() => import('./nodes/5.js'))
		],
		routes: [
			{
				id: "/",
				pattern: /^\/$/,
				params: [],
				page: { layouts: [0,], errors: [1,], leaf: 2 },
				endpoint: null
			},
			{
				id: "/gallery",
				pattern: /^\/gallery\/?$/,
				params: [],
				page: { layouts: [0,], errors: [1,], leaf: 3 },
				endpoint: null
			},
			{
				id: "/gallery/images",
				pattern: /^\/gallery\/images\/?$/,
				params: [],
				page: { layouts: [0,], errors: [1,], leaf: 4 },
				endpoint: null
			},
			{
				id: "/services",
				pattern: /^\/services\/?$/,
				params: [],
				page: { layouts: [0,], errors: [1,], leaf: 5 },
				endpoint: null
			}
		],
		matchers: async () => {
			
			return {  };
		}
	}
}
})();
